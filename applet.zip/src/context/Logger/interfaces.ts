export interface ILogger {
    log(level: string, mesg: string): void;
}
