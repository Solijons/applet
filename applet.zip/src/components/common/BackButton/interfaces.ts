export interface IBackButtonProps {
  dest: string;
  text: string;
}
