export enum APP_ENV {
    dev = 0,
    "non-prod" = 1,
    prod = 2
}
