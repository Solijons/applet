This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Configuration
### Hosts
The application is self configuring based upon the hostname where the
application is accessed. The following are valid hostnames:

* `localhost` - development server
* `tractivity.breeding-np.ag` - non-prod server
* `tractivity.breeding.ag` - prod server

### Client Secret
A *client secret* **MUST** be placed in the `src/config` directory
for production, non-production and development environments (the
non-production secret will be used in the development environment).
The files **MUST** exist:

* `src/config/dev.config.json`
* `src/config/non-prod.config.json`
* `src/config/prod.config.json`

These files **MUST** have this shape.

#### Example
```
$ cat src/config/default.json
{
    "env": "default",
    "services": {
      "iam": {
        "oauth2": {
            "clientId": "",
            "clientSecret": "",
            "host": ""
        },
      },
      "sites": {
        "siteName": {
            "longName": "",
            "prefix": "",
            "programs": []
        },
      },
      "serviceName": {
        "url": "",
      }
    }
}
```

### Teams
The teams used in the application are pulled from
[PAPI](https://devtools.monsanto.net/docs/authorization/papi). Each
team name **MUST**  have a common `SITE_PREFIX`. For example, teams at
the Kihei site are all prefixed with `TPD_Maui_`. Also, each **MUST**
end with `_Team`.

## Available Scripts
In the project directory, you can run:

### `npm run dev`

Runs the app in the development mode.<br>
Open [http://localhost:8080](http://localhost:8080) to view it in the browser.

The page will reload if you make edits.<br>
You will also see any lint errors in the console.

Development with Docker
-----------------------
Scripts are provided to build a Docker image and create a Docker
container. The container can be used as a controlled development
environment.

### Build Image and Create Container
```bash
# Build image
$> npm run build-image

> tractivity-ui@0.1.0 build-image /Users/jfavr1/dev/experimental/tractivity
> docker image build -t tractivity-ui:dev .

Sending build context to Docker daemon  920.1kB
Step 1/10 : FROM node:10.15.0-alpine
 ---> 288d2f688643
Step 2/10 : EXPOSE 3000
 ---> Using cache
 ---> a630b3e936f3
Step 3/10 : RUN mkdir /app

... output omitted ...
```

```bash
# Create and start container
$> npm run start-container

> tractivity-ui@0.1.0 start-container /Users/jfavr1/dev/experimental/tractivity
> docker run -d --name tractivity-ui -v ${PWD}:/app -v /app/node_modules -p 8080:3000 --rm tractivity-ui:dev

21c10b4d6c3905292a0739133850b267b61bb4f8cb8c605af8ff70f4ee5a7bbf
```

### Restarting and Stopping the Container
```bash
# Stop the container
$> npm run stop-container

# Restart the container
$> npm run restart container
```

### Connecting to the Container
The containerized application is made available via localhost on port
8080. The local source files are mounted inside the container, so
changes to them will immediately be reflected.

Changes to the `package.json` file, including the adding of
dependencies necessitate the rebuilding of the Docker image.

First stop the container, then rebuild the image, finally run a
container with the new base image.

```bash
# Stop the container (container is deleted)
$> npm run container-stop

# Rebuild the image
$> npm run build-image

# Start a new container
$> npm run start-container
```

### `npm test`

Launches the test runner.

#### Tests Configuration
Copy the `Test/src/test/resources/config.properties-template` file to
Test/src/test/resources/local.properties` and update accordingly.

```
web.baseUrl = http://localhost:8080
web.MONUSERNAME = MONUSERNAME
web.MONPASSWORD = MONPASSWORD
```

### `npm run build`
Build the application for production. The production build is hosted
using [serve](https://www.npmjs.com/package/serve)

#### Serving Build Example
```
// The -s flag is for single page Web apps (SPAs).

node node_modules/serve/bin/serve -s build
```