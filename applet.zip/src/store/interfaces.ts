export interface IStoreTeamsProps {
  eventTeams: [];
  papiTeams: [];
}
