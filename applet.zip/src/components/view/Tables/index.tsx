import React from 'react';
import MaterialTableDemo from './MaterialTableDemo';

export default function Tables() {
  return (
    <React.Fragment>
      <MaterialTableDemo />
    </React.Fragment>
  );
}
